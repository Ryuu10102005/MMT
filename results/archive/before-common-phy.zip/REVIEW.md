# Review code theo PLAN.md

Nguồn đối chiếu: `F:/BTL_MMT_detai/PLAN.md`. Phạm vi lần sửa này là mã mô phỏng, cấu hình, kiểm thử, thí nghiệm và phân tích dữ liệu trong `BTL_MMT`.

## Các vấn đề đã xử lý

| Vấn đề trước review | Ảnh hưởng | Thay đổi |
| --- | --- | --- |
| Phân tích tìm mọi file scalar bằng glob, không kiểm tra manifest | Có thể trộn dữ liệu cũ, thiếu run hoặc khác phiên bản nguồn vào báo cáo | Chỉ đọc run được liệt kê trong manifest hoàn tất; kiểm tra mã băm nguồn, executable, file kết quả và metadata |
| Không gắn executable với nguồn đã build | Có thể sửa C++ nhưng chạy executable cũ rồi ghi mã băm nguồn mới | Build thành công ghi `build-info.json`; runner và phân tích kiểm tra lại fingerprint |
| Số run được ghi cứng mà không đối chiếu cấu hình thực | Sửa ini có thể khiến thí nghiệm chạy thiếu hoặc sai run | Truy vấn danh sách run từ OMNeT++ và đối chiếu ma trận đã chốt |
| Kiểm thử và nghiên cứu dùng chung thư mục kết quả | Các run kiểm thử ngắn có thể bị nhầm với dữ liệu nghiên cứu | Kiểm thử ghi vào `results/tests`, thí nghiệm ghi vào `results/verified` |
| BEB chỉ được kiểm tra bằng cận chung 1023 | Chưa chứng minh cận theo giai đoạn va chạm và giới hạn cấu hình | Ghi `backoffExponent` cùng `backoffSlots`; kiểm tra từng lần rút và trường hợp cap 0/2 |
| Thiếu kiểm thử va chạm ALOHA, truyền lại Slotted và biên warmup | Dễ bỏ sót lỗi cơ chế hoặc thứ tự sự kiện tại cùng thời điểm | Thêm các cấu hình kiểm thử tất định tương ứng |
| Tham số có thể tạo thời lượng bị làm tròn về 0 hoặc bus không có nút | Khe Slotted không hợp lệ hoặc mạng rỗng vẫn chạy | Từ chối tham số không hữu hạn, thời lượng không dương ở độ phân giải hiện hành và bus không có nút |
| Kết thúc trước warmup chưa có snapshot đầu kỳ | Đối soát tồn kho không còn đúng với cửa sổ đo rỗng | Ghi hai biên bằng tồn cuối kỳ, thời gian đo bằng 0; phân tích từ chối cửa sổ đo rỗng |
| Phân tích chưa trình bày so sánh 20s với 100s | Chưa thực hiện phần kiểm tra độ ổn định trong plan | Tổng hợp và vẽ riêng kết quả Stability cùng ba mức tải tương ứng |
| Cấu hình `.anf` đọc đường dẫn kết quả cũ | OMNeT++ IDE có thể hiển thị dữ liệu chưa xác minh | Chuyển sang `results/verified/CsmaCd-*` |

## Đối chiếu thiết kế

- Giữ mô hình CSMA/CD trên bus có trễ lan truyền, jam và BEB; chỉ hoàn thành khung CSMA/CD khi thời gian khung lớn hơn hai lần trễ lan truyền cực đại. Giữ thứ tự ưu tiên sự kiện để phân biệt khoảng phát nửa kín của baseline ALOHA.
- Giữ G là tải gói mới toàn mạng. RNG tạo gói và RNG backoff tách nhau; ba giao thức dùng cùng N, bitrate, kích thước khung, hàng đợi, thời lượng và seed.
- Giữ bộ đếm theo thời điểm sự kiện trong cửa sổ đo; kiểm tra `initialPending + generated - blocked = success + dropped + finalPending` cho từng nút.
- Giữ 345 run: CsmaCd 45, Aloha 45, Slotted 45, StudyN 60, StudyA 75, StudyBEB 60, Stability 15; tổng cộng 69 bộ tham số, mỗi bộ 5 seed.
- Báo cáo số gói thành công, thông lượng chuẩn hóa và bit/s, tỷ lệ va chạm, độ trễ, truyền lại và tỷ số chặn/loại; thanh sai số là độ lệch chuẩn mẫu giữa các seed.
- Không dùng `ketqua.csv` hay áp đường lý thuyết ALOHA trực tiếp theo G gói mới có hàng đợi và truyền lại.

## Kiểm chứng

Ngày 14/11/2026: build release thành công, **23/23 kiểm thử tích hợp** và **12/12 kiểm thử workflow** đạt. Workflow kiểm tra việc từ chối nguồn/executable/kết quả bị thay đổi, run thiếu hoặc trùng, metadata sai, seed trùng, và tổng hợp metric không xác định.

Đã chạy lại **345/345 run**, tổng hợp **69 bộ tham số**, mỗi bộ đủ **5 seed**, và xuất **10 biểu đồ**. Manifest có trạng thái `complete`; tất cả metric trong bộ dữ liệu này có đủ 5 seed hợp lệ. Kiểm tra trực quan biểu đồ so sánh thông lượng và kiểm tra thời lượng cho thấy nhãn, đơn vị, chú giải và thanh sai số hiển thị đầy đủ.

| G | S trung bình, run 20s / warmup 2s | S trung bình, run 100s / warmup 10s | Thay đổi tương đối |
| --- | --- | --- | --- |
| 0.1 | 0.099822 | 0.099700 | -0.1224% |
| 0.6 | 0.598589 | 0.602744 | +0.6942% |
| 1.5 | 0.891911 | 0.892489 | +0.0648% |

Các chỉ tiêu độ trễ, va chạm và chặn/loại của phép kiểm tra thời lượng được lưu cùng trong `results/summary/stability.csv`.

Lệnh tái lập:

```powershell
./scripts/build.ps1
python scripts/run.py test
python -m unittest discover -s scripts -p test_workflow.py -v
python scripts/run.py experiments
python scripts/analyze.py
```

Kết quả kiểm thử nằm trong `results/tests/tests.json`; dữ liệu thí nghiệm và fingerprint nằm trong `results/verified/manifest.json`. `results/summary/runs.csv` và `summary.csv` được dựng từ scalar đã kiểm tra, không từ CSV cũ.

## Phần còn lại của bài nộp

Hoàn tất code và dữ liệu không đồng nghĩa hoàn tất mọi sản phẩm của PLAN.md. Báo cáo PDF 15–25 trang, slide bảo vệ, video 3–5 phút hoặc minh chứng được chấp nhận, tên/MSSV của 5 thành viên, nhật ký đóng góp thực tế, xác nhận phạm vi và gói ZIP nộp bài vẫn cần chuẩn bị riêng. Không tự gán đóng góp hay phê duyệt giảng viên.
