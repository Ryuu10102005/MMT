#include <omnetpp.h>
#include <cmath>
#include <set>

using namespace omnetpp;

class Bus : public cSimpleModule
{
  protected:
    simtime_t maxProp;
    std::set<int> active;
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
};

Define_Module(Bus);

void Bus::initialize()
{
    double propagation = par("maxPropDelay").doubleValue();
    if (!std::isfinite(propagation) || propagation < 0)
        throw cRuntimeError("maxPropDelay must be finite and nonnegative");
    int numNodes = getParentModule()->par("numNodes");
    if (numNodes < 1 || gateSize("in") != numNodes || gateSize("out") != numNodes)
        throw cRuntimeError("The bus requires at least one node and one gate pair per node");
    maxProp = SimTime(propagation);
}

void Bus::handleMessage(cMessage *msg)
{
    int src = msg->getArrivalGate()->getIndex();
    int n = gateSize("out");
    // ALOHA baselines use an ideal common collision domain with half-open
    // transmission intervals. Carrier sensing for CSMA/CD remains delayed.
    if (msg->getKind() == 1) {
        if (!active.empty()) {
            std::set<int> affected = active;
            affected.insert(src);
            for (int id : affected) {
                auto *collision = new cMessage("collision", 3);
                collision->setSchedulingPriority(0);
                send(collision, "out", id);
            }
        }
        active.insert(src);
    }
    else active.erase(src);

    for (int j = 0; j < n; j++) {
        if (j == src)
            continue;
        double frac = (n > 1) ? std::fabs((double)(j - src)) / (n - 1) : 0.0;
        simtime_t d = maxProp * frac;
        sendDelayed(msg->dup(), d, "out", j);
    }
    delete msg;
}
